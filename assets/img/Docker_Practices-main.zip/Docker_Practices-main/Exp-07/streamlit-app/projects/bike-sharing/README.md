# Tutorial: Bicycle Demand Monitoring

### Run pipeline

1. Launch `Jupyter Notebook`:

    ```bash
    jupyter-notebook
    ```
2. Open notebook `bicycle_demand_monitoring.ipynb`
3. Run all cells

